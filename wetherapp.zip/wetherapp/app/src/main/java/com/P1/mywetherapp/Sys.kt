package com.P1.mywetherapp

data class Sys(
    val country: String,
    val sunrise: Int,
    val sunset: Int
)