package com.P1.mywetherapp

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)