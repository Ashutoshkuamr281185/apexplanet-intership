package com.P1.mywetherapp

data class Coord(
    val lat: Double,
    val lon: Double
)