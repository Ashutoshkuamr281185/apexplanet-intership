package com.P1.mywetherapp

data class Clouds(
    val all: Int
)